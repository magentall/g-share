<div id="footer" class="container">
	<div class="text-align-center">
Copyright &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?>. <?php _e('Powered by', 'prpin'); ?>
<a href="//wordpress.org" title="WordPress"><?php _e('WordPress', 'prpin'); ?></a>   &amp;
<a href="//www.premiumresponsive.com" title="<?php _e('PR Pin Theme', 'prpin'); ?>"><?php _e('PR Pin Theme', 'prpin'); ?></a>
   </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
