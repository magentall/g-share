<?php 
	$allm_post_id = (int) get_the_ID();
	$allm_class = 'audio';
	if ( 'false' == get_option('allmed_blog_style') ) $allm_class .= ' entry';
?>
<article id="<?php echo esc_attr( "post-{$allm_post_id}" ); ?>" <?php post_class( $allm_class ); ?>>
	<?php
		$thumb = '';
		$width = apply_filters( 'allm_audio_format_image_width', 176 );
		$height = apply_filters( 'allm_audio_format_image_height', 176 );
		$classtext = 'audio-image';
		$titletext = strip_tags( get_the_title() );
		$thumbnail = allm_get_thumbnail($width,$height,$classtext,$titletext,$titletext,false,'Audio');
		$thumb = $thumbnail["thumb"];
	?>

	
	<div class="content" onclick="location.href='<?php the_permalink(); ?>';" style="cursor: pointer;">
		<div class="audio_info"> 
			<h2 class="title"><a href="<?php the_permalink(); ?>"><?php allm_short_title(25); ?></a></h2>
			<?php get_template_part('includes/postinfo'); ?>
		</div> <!-- end .audio_info -->
		
		
		
	</div> <!-- end .content -->
</article> <!-- end .entry -->