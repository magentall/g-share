<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
	<?php allm_display_single_post(); ?>

	
<?php endwhile; // end of the loop. ?>