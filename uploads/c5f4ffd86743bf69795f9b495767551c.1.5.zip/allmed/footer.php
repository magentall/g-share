</div>

		</div> <!-- end #content_right -->

	</div> <!-- end #content-area -->
	<div class="foot-max">
			<div id="footer-widgets">
						<?php dynamic_sidebar('Footer'); ?>
					</div> <!-- end #footer-widgets -->
					</div>
			<div class="footer">

<?php do_action( 'allmed_credits' ); ?>
			<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'allmed' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'allmed' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( __( 'Theme: %1$s by %2$s.', 'allmed' ), 'Allmed', '<a href="http://wpmole.com" rel="designer">WPMole</a>' ); ?>

</div>


	<?php wp_footer(); ?>

</body>
</html>