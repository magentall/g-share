var $j = jQuery.noConflict();
$j(function () {

$j(document).ready(function(){
//$j(".thumb img").fadeTo("slow", 0.6); // This sets the opacity of the thumbs to fade down to 60% when the page loads

$j(".thumb img").hover(function(){
$j(this).fadeTo("slow", 0.6); // This should set the opacity to 100% on hover
},function(){
$j(this).fadeTo("slow", 1.0); // This should set the opacity back to 60% on mouseout
});
});

$j("#slideshow li:last").one("click",function(e) {
     $j(this).click(function() {
        $j('#slideshow').trigger( 'next' );
     });
 });

$j('#slideshow').serialScroll({
		items:'li',
		prev:'a.prev',
		next:'a.next',
		offset:-10, //when scrolling to photo, stop 230 before reaching it (from the left)
		start:0, //as we are centering it, start at the 2nd
		duration:1200,
		force:true,
		stop:true,
               	lock:false,
		cycle:true, 
		easing:'easeOutQuart', //use this easing equation for a funny effect
		jump: true

	});
	$j("#dropmenu ul").css({display: "none"}); // Opera Fix
		$j("#dropmenu li").hover(function(){
                    $j(this).addClass('hover-menu');
                    $j(this).find('ul:first').css({visibility: "visible",display: "none"}).slideDown();},
                        function(){
                         $j(this).find('ul:first').css({visibility: "hidden"});
                          $j(this).css('background','none');
			});

        $j('#loopedSlider').loopedSlider({
				addPagination: true,
				slidespeed: 500,
                                containerClick: false
                                //autoStart: 5000
			});

    
        $j("#slideshow ul li").hover(function(){
            $j(this).find('h3').fadeTo("slow", 0);
        }, function() {
           $j(this).find('h3').fadeTo("slow", 1);
        }
    );

// shortcodes js
        $j(".toggle-container").hide();
        $j(".toggle-trigger").click(function(){
                $j(this).toggleClass("active").next().slideToggle();
                return false;
        });

        $j('.tabs-content .tab:first').show();
            $j('.tabs li:first').addClass('active');
            $j.each($j('.tabs li'),function(i,el){
                $j(el).click(function(){
                    $j('.tabs-content .tab').hide();
                    $j('.tabs-content .tab').eq(i).show();
                    $j('.tabs li').removeClass('active');
                    $j(this).addClass('active');
                    return false;
                });
            });
});
