<div class="pagination clearfix">
<div class="wrap-pagin">
	<?php next_posts_link(esc_html__('&laquo; Older Posts','allmed')) ?>
	<?php previous_posts_link(esc_html__('Newer Posts &raquo;', 'allmed')) ?>
</div>
</div>