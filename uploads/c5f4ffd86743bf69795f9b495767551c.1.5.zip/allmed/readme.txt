= Allmed =

Allmed is a theme for video and audio bloggers, with a  minimal design, giving you huge scope to turn the design into anything you like. The theme is simply customizable, you can choose unlimited color schemes.

== License ==

Unless otherwise specified, all the theme files, scripts and images
are licensed under GNU General Public License Version 3 or later.
The exceptions to this license are as follows:
* FancyBox is licensed under MIT and GPL licenses.
* The script DD_belatedPNG_0.0.8a-min.js is licensed under MIT, http://www.dillerdesign.com/experiment/DD_belatedPNG/
* The script jquery.cookie.js is licensed under MIT and GPL, http://github.com/carhartl/jquery-cookie
* The script jquery.jplayer.min.js is licensed under MIT and GPL, http://www.happyworm.com/jquery/jplayer
* The script jquery.easing.1.3.js is licensed under BSD, http://gsgd.co.uk/sandbox/jquery/easing/
* The script jquery.scrollTo-1.4.2-min.js is licensed under MIT and GPL, http://flesler.blogspot.com
* The script jquery.serialScroll-1.2.2-min.js is licensed under MIT and GPL, http://flesler.blogspot.com
* The script loopedslider.min.js is licensed under MIT and GPL, http://nathansearles.com/loopedslider/
* The script jquery.masonry.min.js is licensed under MIT, http://masonry.desandro

Allmed WordPress Theme, Copyright 2013 WordPress.org
Allmed is distributed under the terms of the GNU GPL