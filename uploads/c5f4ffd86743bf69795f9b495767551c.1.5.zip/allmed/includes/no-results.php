<div class="entry">
<!--If no results are found-->
	<h1><?php esc_html_e('No Results Found','allmed'); ?></h1>
	<p><?php esc_html_e('The page you requested could not be found.','allmed'); ?></p>
</div>	
<!--End if no results are found-->