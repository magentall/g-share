<?php get_header(); ?>

<div id="regular_content">

	<?php get_template_part('loop','page'); ?>
	
	<?php comments_template( '', true ); ?>
</div> <!-- end #regular_content -->

<?php get_footer(); ?>