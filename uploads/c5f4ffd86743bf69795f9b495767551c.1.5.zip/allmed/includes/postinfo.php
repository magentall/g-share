<?php 
$option_name = 'allmed_postinfo1' ;
$new_value = array( 'author', 'date' ) ;
update_option( $option_name, $new_value );
if ( ! is_single() && 'false' == get_option('allmed_blog_style') && ( $index_postinfo = get_option('allmed_postinfo1') ) && $index_postinfo ) { ?>
	<p class="meta">
	<?php
update_option( 'allmed_date_format', 'Y/m/d' );
		allm_postinfo_meta( $index_postinfo, get_option('allmed_date_format'), esc_html__('0 comments','allmed'), esc_html__('1 comment','allmed'), '% ' . esc_html__('comments','allmed') ); ?>
	</p>
<?php } 

else
$option_name = 'allmed_postinfo2' ;
$new_value = array( 'author', 'date', 'categories' ) ;
update_option( $option_name, $new_value );
 if ( ( is_single() && get_option('allmed_postinfo2') ) || 'on' == get_option('allmed_blog_style') ) { ?>
	<p class="meta-info">
		<?php global $query_string;
		$new_query = new WP_Query($query_string);
		while ($new_query->have_posts()) $new_query->the_post(); ?>
			<?php allm_postinfo_meta( get_option('allmed_postinfo2'), get_option('allmed_date_format'), esc_html__('0 comments','allmed'), esc_html__('1 comment','allmed'), '% ' . esc_html__('comments','allmed') ); ?>
		<?php wp_reset_postdata() ?>
	</p>
<?php }; ?>