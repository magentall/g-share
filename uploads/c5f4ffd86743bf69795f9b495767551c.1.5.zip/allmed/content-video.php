<?php 
	$allm_class = 'video';
	if ( 'false' == get_option('allmed_blog_style') ) $allm_class .= ' entry';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $allm_class ); ?>>
	<?php
		$thumb = '';
		$width = apply_filters( 'allm_video_format_image_width', 280 );
		$height = apply_filters( 'allm_video_format_image_height', 180 );
		$classtext = 'video-image';
		$titletext = strip_tags( get_the_title() );
		$thumbnail = allm_get_thumbnail($width,$height,$classtext,$titletext,$titletext,false,'Photo');
		$thumb = $thumbnail["thumb"];
		$allm_videolink = get_post_meta( $post->ID, '_et_allmed_video_url', true );
	?>
	<?php if( '' != $thumb && 'on' == get_option('allmed_thumbnails_index') ) { ?>
		<div class="img">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?>
				
				<span class="play"></span>
			</a>
		</div> 	<!-- end .img -->
	<?php } ?>
	
	<div class="content" onclick="location.href='<?php the_permalink(); ?>';" style="cursor: pointer;">
		<h2 class="title"><a href="<?php the_permalink(); ?>"><?php allm_short_title(25); ?></a></h2>
		
		<?php get_template_part('includes/postinfo'); ?>
	</div>
</article> <!-- end .entry-->