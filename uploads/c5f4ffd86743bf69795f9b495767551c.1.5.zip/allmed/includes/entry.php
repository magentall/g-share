<?php 

	 update_option('allmed_blog_style', 'false');
	$allmed_blog_style = get_option('allmed_blog_style');
?>

<?php
	if ( 'on' == $allmed_blog_style ) echo '<div id="regular_content">';
	else echo '<div id="et_posts">';
?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<?php 
			if ( 'false' == $allmed_blog_style ) get_template_part( 'content', get_post_format() );
			else allm_display_single_post();
		?>
	<?php endwhile; ?>
<?php if ( 'false' == $allmed_blog_style ) echo '</div>';?>
	<?php if ( function_exists('wp_pagenavi') ) { wp_pagenavi(); }
		else { ?>
			 <?php get_template_part('includes/navigation'); ?>
		<?php } ?>
	<?php else : ?>
		<?php get_template_part('includes/no-results'); ?>
	<?php endif; if ( is_home() ) wp_reset_query(); ?>
<?php if ( 'on' == $allmed_blog_style ) echo '</div>';?>