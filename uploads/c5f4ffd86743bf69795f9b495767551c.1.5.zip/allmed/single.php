<?php get_header(); ?>

<div id="regular_content">
	<?php get_template_part('includes/breadcrumbs','index'); ?>

	<?php get_template_part('loop','single'); ?>
	
	<?php update_option('allmed_show_postcomments', 'on');
	if ( 'on' == get_option('allmed_show_postcomments') ) comments_template('', true); ?>
</div> <!-- end #regular_content -->

<?php get_footer(); ?>