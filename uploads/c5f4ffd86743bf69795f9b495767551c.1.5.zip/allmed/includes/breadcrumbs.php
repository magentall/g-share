<div id="breadcrumbs">
	<?php if(function_exists('bcn_display')) { bcn_display(); } 
		  else { ?>

				
				<?php if( is_tag() ) { ?>
					<?php esc_html_e('Posts Tagged ','allmed') ?><span class="raquo">&gt;</span><?php single_tag_title(); echo('&gt;'); ?>
				<?php } elseif (is_day()) { ?>
					<?php esc_html_e('Posts made in','allmed') ?> <?php the_time('F jS, Y'); ?>
				<?php } elseif (is_month()) { ?>
					<?php esc_html_e('Posts made in','allmed') ?> <?php the_time('F, Y'); ?>
				<?php } elseif (is_year()) { ?>
					<?php esc_html_e('Posts made in','allmed') ?> <?php the_time('Y'); ?>
				<?php } elseif (is_search()) { ?>
					<?php esc_html_e('Search results for','allmed') ?> <?php the_search_query() ?>
				<?php } elseif (is_single()) { ?>
					
				<?php } elseif (is_page()) { ?>
					<?php wp_title(''); ?>
				<?php }; ?>
	<?php }; ?>
</div> <!-- end #breadcrumbs -->