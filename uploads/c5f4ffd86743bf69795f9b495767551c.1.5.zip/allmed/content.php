<?php 
	$allm_class = 'normal-post';
	 update_option('allmed_blog_style', 'false');
	if ( 'false' == get_option('allmed_blog_style') ) $allm_class .= ' entry';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $allm_class ); ?>>
	
	<div class="main_content">
		<?php
			$thumb = '';
			$width = apply_filters( 'allm_normal_format_image_width', 80 );
			$height = apply_filters( 'allm_normal_format_image_height', 80 );
			$classtext = 'n-post-image';
			$titletext = strip_tags( get_the_title() );
			$thumbnail = allm_get_thumbnail($width,$height,$classtext,$titletext,$titletext,false,'Entry');
			$thumb = $thumbnail["thumb"];
		?>
	<?php if( '' != $thumb && 'on' == get_option('allmed_thumbnails_index') ) { ?>
			<div class="thumb">
				<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?>
					<span class="overlay"></span>
				</a>
			</div> 	<!-- end .thumb -->
		<?php } ?> 
		
		<div class="content" onclick="location.href='<?php the_permalink(); ?>';" style="cursor: pointer;">
<!--			<p><?php allm_truncate_post(75); ?></p>
			<div class="readmore">
  <a href="<?php the_permalink() ?>"><?php _e('Read more', 'allmed'); ?></a>
  </div>-->
			   <h2 class="title"><a href="<?php the_permalink(); ?>"><?php allm_short_title(25); ?></a></h2>
			<?php get_template_part('includes/postinfo'); ?>
		</div> <!-- end .content-->
	</div> <!-- end .main_content-->
		
	<!--<div class="center_layer"></div>
	<div class="bottom_layer"></div>-->
</article> <!-- end .entry-->