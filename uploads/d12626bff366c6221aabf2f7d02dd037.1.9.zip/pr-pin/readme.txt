Thanks for choosing  PR Pin Theme.

Theme Homepage:  http://www.premiumresponsive.com/pr-pin-wordpress-theme/
 
 ##################### Requirements #####################
- PHP 5+
- Wordpress  3.5+ required

####################### Licenses ########################
PR Pin WordPress theme, Copyright (C) 2013 Algimanats Kilius
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License, version 3: http://opensource.org/licenses/GPL-3.0 
The exceptions to this license are as follows:
* Bootstrap v3.0.3 by Twitter and the Glyphicon set are licensed under the GPL-compatible  http://www.apache.org/licenses/LICENSE-2.0 Apache License v2.0
* The script bootstrap-carousel.js v2.3.0 is licensed under the Apache License
* Bootstrap Image Gallery    Licensed under the MIT license:  http://www.opensource.org/licenses/MIT
* jQuery  Licensed under the MIT license
* Options Framework for building theme options Author Devin Price Licensed GPLv2
* Class  wp_bootstrap_navwalker  Author  Edward McIntyre - @twittem Licensed  GPL-2.0+
* Font Awesome font is licensed under SIL OFL 1.1  http://scripts.sil.org/OFL

